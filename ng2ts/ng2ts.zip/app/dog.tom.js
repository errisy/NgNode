"use strict";
var Dog = (function () {
    function Dog() {
        this.Test = "test property";
    }
    return Dog;
}());
exports.Dog = Dog;
//# sourceMappingURL=dog.tom.js.map