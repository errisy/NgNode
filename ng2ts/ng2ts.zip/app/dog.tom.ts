﻿export class Dog {
    public Name: string;
    public Test: string = "test property";
}