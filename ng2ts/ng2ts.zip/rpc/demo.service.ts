export class Demo {
	public test():  string{
	}
	public tom():  Dog{
	}
	public jerry(){
	}
}
