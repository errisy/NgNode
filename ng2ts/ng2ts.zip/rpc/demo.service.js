"use strict";
var Demo = (function () {
    function Demo() {
    }
    Demo.prototype.test = function () {
    };
    Demo.prototype.tom = function () {
    };
    Demo.prototype.jerry = function () {
    };
    return Demo;
}());
exports.Demo = Demo;
//# sourceMappingURL=demo.service.js.map