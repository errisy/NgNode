declare module "tester" {
    export var job: "string"|"number";

}